package com.example.agapovlr2;


import org.junit.Test;

public class TestAuthor {
    @Test
    public void TestAuthor(){
        Author a1 = new Author("Ivanov", "ivanov@nikuda.com");
        System.out.println(a1);

        a1.setName("Ivanov");
        a1.setEmail("ivanov@nikuda.com");
        System.out.println(a1);
        System.out.println("name: " + a1.getName());
        System.out.println("email: " + a1.getEmail());

    }
}
