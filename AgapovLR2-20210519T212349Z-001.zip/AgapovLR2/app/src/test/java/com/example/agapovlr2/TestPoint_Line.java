package com.example.agapovlr2;



import org.junit.Test;

public class TestPoint_Line {

    @Test
    public void TestPoint_Line(){

        Point p1 = new Point(1,3 );
        System.out.println(p1);

        Point p2 = new Point();

        Line l1 = new Line(1,3 ,3 ,4);
        System.out.println(l1);
    }

}
